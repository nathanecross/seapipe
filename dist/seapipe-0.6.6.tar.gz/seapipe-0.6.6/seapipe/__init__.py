"""
SEA main module
"""

__author__ = 'Nathan Cross'
__credits__ = 'Concordia University (Canada), University of Sydney (Australia)'

from .version import __version__

from seapipe.core.dataset import pipeline




