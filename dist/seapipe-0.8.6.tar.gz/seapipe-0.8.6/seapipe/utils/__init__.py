"""Packages containing power spectral analyses

"""


# from .audit import (check_dataset, make_bids, extract_channels, 
#                     track_processing, check_fooof)
# from .load import (select_input_dirs, select_output_dirs, check_chans,
#                    load_channels, rename_channels, check_adap_bands,
#                    read_manual_peaks, load_adap_bands, read_inversion)
# from .logs import (CustomFormatter, CustomLogfileFormatter, create_logger,
#                    create_logger_empty, create_logger_basic, 
#                    create_logger_outfile)
# from .process import parallel
# from .misc import (clean_annots, remove_event, remove_duplicate_evts, 
#                    remove_duplicate_evts, merge_xmls, rainbow_merge_evts, 
#                    rename_evts, laplacian_mne, notch_mne, notch_mne2, 
#                    bandpass_mne, csv_stage_import)
# from .splitter import extract_grouped_markers

__all__ = ["SONAR"]

def __getattr__(name):
    if name == "SONAR":
        from .spectrogram import SONAR
        return SONAR
    raise AttributeError(f"module 'seapipe.utils' has no attribute '{name}'")
